package com.w2a.testcases;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.w2a.base.TestBase;

public class AddCustomerTest extends TestBase {
	
	//to remove the number of arugmntes in methods, HashTable <String String> data in addCustomer(HashTable <String String> data)

	@Test(dataProvider = "getData")
	public void addCustomer(String firstName, String lastName, String postCode, String alertText, String runmode)
			throws Exception {
		// verifyEquals("abc", "xyz");
		System.setProperty("org.uncommons.reportng.escape-output", "false");

		/*if (!runmode.equals("Y")) {
			throw new SkipException("Skipping the test case as the run mode for data set is No");

		}*/
		click("addCusBtn_CSS");
		type("firstName_CSS", firstName);
		type("lastName_CSS", lastName);
		type("postCode_CSS", postCode);
		click("addBtn_CSS");

		// driver.findElement(By.cssSelector(OR.getProperty("addCusBtn"))).click();
		// driver.findElement(By.cssSelector(OR.getProperty("firstName"))).sendKeys(firstName);
		// driver.findElement(By.cssSelector(OR.getProperty("lastName"))).sendKeys(lastName);
		// driver.findElement(By.cssSelector(OR.getProperty("postCode"))).sendKeys(postCode);
		// driver.findElement(By.cssSelector(OR.getProperty("addBtn"))).click();

		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		Assert.assertTrue(alert.getText().contains(alertText));
		alert.accept();
		Reporter.log("Login Successfully Executed");
		Reporter.log("<a target=\"blank\" href=\"D:\\screenShort\\qwe.jpg\">Screenshot</a>");

		// Assert.fail("Login not Successful");

	}

	@DataProvider
	public Object getData() {

		String sheetName = config.getProperty("ExcelSheetName");
		int rows = excel.getRowCount(sheetName);
		int cols = excel.getColumnCount(sheetName);
		Object[][] data = new Object[rows - 1][cols];
		for (int rowNum = 2; rowNum <= rows; rowNum++) {
			for (int colNum = 0; colNum < cols; colNum++) {
				// data[0][0]
				data[rowNum - 2][colNum] = excel.getCellData(sheetName, colNum, rowNum);

			}

		}
		return data;

	}

}
