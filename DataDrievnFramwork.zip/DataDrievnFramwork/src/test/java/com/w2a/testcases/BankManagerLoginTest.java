package com.w2a.testcases;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.w2a.base.TestBase;

public class BankManagerLoginTest extends TestBase {
	@Test
	public void bankManagerLoginTest() throws Exception {

		/*
		 * try { Assert.assertEquals("abc", "xyz");// didn't go for next level
		 * log.debug("after assertion"); } catch (Throwable t) {
		 * log.debug("inside catch block"); }
		 */

	verifyEquals("abc", "xyz");

		log.debug("Inside Login Test");
		// driver.findElement(By.cssSelector(OR.getProperty("bmlBtn"))).click();
		click("bmlBtn_CSS");

		Assert.assertTrue(isElementPresent(By.cssSelector(OR.getProperty("addCusBtn_CSS"))), "Login not successfully");
		log.debug("Login Successfully Executed");

		Assert.fail("Login not Successful");

	}

}
