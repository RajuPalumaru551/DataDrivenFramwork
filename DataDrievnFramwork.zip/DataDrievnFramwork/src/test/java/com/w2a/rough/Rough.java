package com.w2a.rough;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Rough {
	 String result_title = "Sharath";

     String required_title = "Nuthan";

     SoftAssert softassert = new SoftAssert();

     @Test

     public void validateTitles() {

     softassert.assertEquals(result_title, required_title);


     }
	
	

}
